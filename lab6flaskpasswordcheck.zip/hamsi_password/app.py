from flask import Flask, render_template, request, redirect, url_for, flash, g, session
import sqlite3
import re

app = Flask(__name__)
app.secret_key = 'supersecretkey'
app.config['SESSION_TYPE'] = 'filesystem'

DATABASE = 'passwords.db'

def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
    return db

@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()

def create_table():
    with app.app_context():
        db = get_db()
        cursor = db.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL,
                password TEXT NOT NULL
            )
        ''')
        db.commit()

def check_password_requirements(password):
    errors = []
    if not re.search(r'[a-z]', password):
        errors.append("You did not use a lowercase character.")
    if not re.search(r'[A-Z]', password):
        errors.append("You did not use an uppercase character.")
    if not re.search(r'\d$', password):
        errors.append("You did not end your password with a number.")
    if len(password) < 8:
        errors.append("Your password is not at least 8 characters long.")
    return errors

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/check_password', methods=['POST'])
def check_password():
    username = request.form['username']
    password = request.form['password']
    errors = check_password_requirements(password)

    if 'failed_attempts' not in session:
        session['failed_attempts'] = 0

    if errors:
        session['failed_attempts'] += 1
        if session['failed_attempts'] >= 3:
            flash("Warning: 3 consecutive failed attempts!")
        return render_template('report.html', errors=errors)
    else:
        session['failed_attempts'] = 0
        db = get_db()
        cursor = db.cursor()
        cursor.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, password))
        db.commit()
        flash("Your password passed the 3 requirements and has been stored to the database!")
        return render_template('report.html', errors=None)
@app.route('/view_passwords')
def view_passwords():
    db = get_db()
    cursor = db.cursor()
    cursor.execute("SELECT username, password FROM users")
    users = cursor.fetchall()
    return render_template('view_passwords.html', users=users)


if __name__ == '__main__':
    create_table()
    app.run(debug=True)
