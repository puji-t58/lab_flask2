document.addEventListener('DOMContentLoaded', (event) => {
    console.log("DOM fully loaded and parsed");
    // Add any JavaScript functionalities or animations here if needed
});
