// script.js

// Unit Converter Functions
function convertWeight(conversionType) {
    let kg = parseFloat(document.getElementById("kg").value);
    let pounds = parseFloat(document.getElementById("pounds").value);

    if (conversionType === 'kgToLb' && !isNaN(kg)) {
        document.getElementById("pounds").value = (kg * 2.20462).toFixed(2);
    } else if (conversionType === 'lbToKg' && !isNaN(pounds)) {
        document.getElementById("kg").value = (pounds / 2.20462).toFixed(2);
    }
}

function convertDistance(conversionType) {
    let km = parseFloat(document.getElementById("km").value);
    let miles = parseFloat(document.getElementById("miles").value);

    if (conversionType === 'kmToMi' && !isNaN(km)) {
        document.getElementById("miles").value = (km * 0.621371).toFixed(2);
    } else if (conversionType === 'miToKm' && !isNaN(miles)) {
        document.getElementById("km").value = (miles / 0.621371).toFixed(2);
    }
}

function convertTemperature(conversionType) {
    let celsius = parseFloat(document.getElementById("celsius").value);
    let fahrenheit = parseFloat(document.getElementById("fahrenheit").value);

    if (conversionType === 'cToF' && !isNaN(celsius)) {
        document.getElementById("fahrenheit").value = (celsius * 9/5 + 32).toFixed(2);
    } else if (conversionType === 'fToC' && !isNaN(fahrenheit)) {
        document.getElementById("celsius").value = ((fahrenheit - 32) * 5/9).toFixed(2);
    }
}

// Calculator Functions
let display = document.getElementById("display");

function appendCharacter(character) {
    display.value += character;
}

function clearDisplay() {
    display.value = "";
}

function calculate() {
    try {
        display.value = eval(display.value.replace('^', '**'));
    } catch (error) {
        display.value = "Error";
    }
}

function scientificOperation(operation) {
    try {
        let currentValue = parseFloat(display.value);
        let result;
        switch (operation) {
            case 'sqrt':
                result = Math.sqrt(currentValue);
                break;
            case 'sin':
                result = Math.sin(currentValue * Math.PI / 180); // converting to radians
                break;
            case 'cos':
                result = Math.cos(currentValue * Math.PI / 180); // converting to radians
                break;
            case 'tan':
                result = Math.tan(currentValue * Math.PI / 180); // converting to radians
                break;
            case 'log':
                result = Math.log10(currentValue);
                break;
            case 'ln':
                result = Math.log(currentValue);
                break;
            default:
                result = "Error";
        }
        display.value = result;
    } catch (error) {
        display.value = "Error";
    }
}

// Real-time Conversion Updates
document.getElementById("kg").addEventListener("input", function() {
    convertWeight('kgToLb');
});

document.getElementById("pounds").addEventListener("input", function() {
    convertWeight('lbToKg');
});

document.getElementById("km").addEventListener("input", function() {
    convertDistance('kmToMi');
});

document.getElementById("miles").addEventListener("input", function() {
    convertDistance('miToKm');
});

document.getElementById("celsius").addEventListener("input", function() {
    convertTemperature('cToF');
});

document.getElementById("fahrenheit").addEventListener("input", function() {
    convertTemperature('fToC');
});
